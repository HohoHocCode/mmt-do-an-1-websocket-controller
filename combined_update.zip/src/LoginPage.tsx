import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  ShieldCheck,
  User,
  ArrowRight,
  Globe,
  Activity,
  CheckCircle2,
  AlertTriangle,
  History,
  Sparkles,
  Fingerprint,
  Lock,
  Search,
  Loader2,
} from "lucide-react";

import { getUser, searchUsers } from "./user_db";
import { useAuth } from "./auth";

type Props = {
  appName: string;
  lockedReason?: string;
};

type PrevSession = {
  username: string;
  loginAt?: string | null;
  logoutAt?: string | null;
};

function formatDate(iso?: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString();
}

function calcDuration(loginAt?: string | null, logoutAt?: string | null) {
  if (!loginAt || !logoutAt) return null;
  const a = new Date(loginAt).getTime();
  const b = new Date(logoutAt).getTime();
  if (!Number.isFinite(a) || !Number.isFinite(b) || b < a) return null;
  const sec = Math.floor((b - a) / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return `${h}h ${mm}m`;
}

export default function LoginPage({
  appName,
  lockedReason,
}: Props) {
  const { login, loading: authLoading, clearLock } = useAuth();

  const [username, setUsername] = useState(() => localStorage.getItem("rdc.lastUsername") || "");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);
  const [prev, setPrev] = useState<PrevSession | null>(null);

  // User browser (client DB)
  const [showUsers, setShowUsers] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const lastUsername = localStorage.getItem("rdc.lastUsername") || "";
    const lastLoginAt = localStorage.getItem("rdc.lastLoginAt");
    const lastLogoutAt = localStorage.getItem("rdc.lastLogoutAt");

    if (lastUsername) {
      setPrev({
        username: lastUsername,
        loginAt: lastLoginAt,
        logoutAt: lastLogoutAt,
      });
    } else {
      setPrev(null);
    }
  }, []);

  const usernameTrimmed = useMemo(() => username.trim(), [username]);
  const passwordTrimmed = useMemo(() => password.trim(), [password]);

  const existingUser = useMemo(() => {
    if (!usernameTrimmed) return false;
    return !!getUser(usernameTrimmed);
  }, [usernameTrimmed]);

  const modeHelp = existingUser
    ? "This username already exists in the client database. You must enter the correct password."
    : "This is a new username. Any non-empty password will be accepted and saved for next time.";

  const matchedUsers = useMemo(() => {
    if (!showUsers) return [];
    return searchUsers(query);
  }, [showUsers, query]);

  const localError = useMemo(() => {
    if (!touched) return null;
    if (!usernameTrimmed) return "Username is required.";
    if (usernameTrimmed.length < 2) return "Username must be at least 2 characters.";
    if (!passwordTrimmed) return "Password is required.";
    return null;
  }, [touched, usernameTrimmed, passwordTrimmed]);

  const canSubmit = useMemo(() => {
    return !!usernameTrimmed && !!passwordTrimmed && !submitting && !authLoading;
  }, [usernameTrimmed, passwordTrimmed, submitting, authLoading]);

  const handleSubmit = async () => {
    setTouched(true);
    if (!usernameTrimmed) return;
    if (!passwordTrimmed) return;

    setError(null);
    setSubmitting(true);
    try {
      await login(usernameTrimmed, passwordTrimmed);
      // do not keep password after successful login
      setPassword("");
    } catch (e: any) {
      setError(e?.message || "Login failed.");
    } finally {
      setSubmitting(false);
    }
  };

  const duration = useMemo(
    () => calcDuration(prev?.loginAt ?? null, prev?.logoutAt ?? null),
    [prev?.loginAt, prev?.logoutAt]
  );

  // Note: do not redeclare `matchedUsers` / `modeHelp` (TS2451). They are defined above.

  return (
    <div className="min-h-screen bg-[#040A18] text-slate-100 relative overflow-hidden">
      {/* Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-56 -left-40 h-[680px] w-[680px] rounded-full bg-blue-600/18 blur-3xl" />
        <div className="absolute -bottom-56 -right-48 h-[720px] w-[720px] rounded-full bg-cyan-500/14 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_12%,rgba(59,130,246,0.22),transparent_45%),radial-gradient(circle_at_82%_74%,rgba(34,211,238,0.16),transparent_48%)]" />
        <div className="absolute inset-0 opacity-[0.08] [background-image:linear-gradient(to_right,rgba(148,163,184,0.22)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,0.22)_1px,transparent_1px)] [background-size:46px_46px]" />

        <div className="absolute left-[10%] top-[18%] h-2 w-2 rounded-full bg-white/20 blur-[1px]" />
        <div className="absolute left-[18%] top-[28%] h-1.5 w-1.5 rounded-full bg-white/15 blur-[1px]" />
        <div className="absolute right-[14%] top-[22%] h-2 w-2 rounded-full bg-white/20 blur-[1px]" />
        <div className="absolute right-[20%] top-[34%] h-1.5 w-1.5 rounded-full bg-white/15 blur-[1px]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 py-10 min-h-screen flex items-center">
        <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          {/* Left: Brand */}
          <div className="relative rounded-3xl border border-slate-700/40 bg-slate-900/25 backdrop-blur-xl p-8 lg:p-10 shadow-[0_30px_120px_-35px_rgba(37,99,235,0.45)] overflow-hidden">
            <div className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full bg-white/5 blur-2xl" />
            <div className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-white/5 blur-2xl" />

            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-2xl bg-blue-500/15 border border-blue-400/30 flex items-center justify-center">
                <ShieldCheck className="h-6 w-6 text-blue-300" />
              </div>
              <div className="min-w-0">
                <p className="text-xs uppercase tracking-[0.35em] text-slate-400">Operator Console</p>
                <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-50 truncate">
                  {appName}
                </h1>
              </div>
            </div>

            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-slate-700/50 bg-slate-950/25 px-3 py-1.5 text-[11px] text-slate-200">
              <Sparkles className="h-4 w-4 text-slate-200" />
              Session entry gateway
            </div>

            <p className="mt-5 text-sm leading-relaxed text-slate-300 max-w-prose">
              Sign in to start an operator session.
            </p>

            <div className="mt-6 h-px w-full bg-gradient-to-r from-transparent via-slate-600/40 to-transparent" />

            <div className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Feature
                icon={<Globe className="h-4 w-4 text-cyan-300" />}
                title="LAN-ready"
                desc="Optimized for lab and internal network operations."
              />
              <Feature
                icon={<Activity className="h-4 w-4 text-blue-300" />}
                title="Operational visibility"
                desc="Processes, console output, and session logs in one place."
              />
              <Feature
                icon={<CheckCircle2 className="h-4 w-4 text-emerald-300" />}
                title="Structured workflow"
                desc="Targets, actions, and commands designed for speed."
              />
              <Feature
                icon={<Fingerprint className="h-4 w-4 text-indigo-300" />}
                title="Session-first"
                desc="Clear lifecycle: enter, operate, sign out."
              />
            </div>

            {/* Previous session */}
            {prev ? (
              <div className="mt-8 rounded-2xl border border-slate-700/50 bg-slate-950/25 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-blue-500/10 border border-blue-400/20">
                      <History className="h-4 w-4 text-blue-300" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold text-slate-100">Previous session</p>
                      <p className="text-[11px] text-slate-400">
                        Last user: <span className="text-slate-200">{prev.username}</span>
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setUsername(prev.username);
                      setPassword("");
                      setTouched(true);
                    }}
                    className="inline-flex items-center gap-2 rounded-xl border border-slate-700/60 bg-slate-950/35 px-3 py-2 text-[11px] text-slate-200 hover:border-blue-500/40 hover:bg-slate-950/55 transition"
                    title="Use last username"
                  >
                    <ArrowRight className="h-4 w-4 text-cyan-300" />
                    Use
                  </button>
                </div>

                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-400">
                  <div className="rounded-xl border border-slate-700/40 bg-slate-950/20 px-3 py-2">
                    <p className="text-slate-500">Login</p>
                    <p className="text-slate-200">{formatDate(prev.loginAt)}</p>
                  </div>
                  <div className="rounded-xl border border-slate-700/40 bg-slate-950/20 px-3 py-2">
                    <p className="text-slate-500">Logout</p>
                    <p className="text-slate-200">{formatDate(prev.logoutAt)}</p>
                  </div>
                  <div className="rounded-xl border border-slate-700/40 bg-slate-950/20 px-3 py-2">
                    <p className="text-slate-500">Duration</p>
                    <p className="text-slate-200">{duration ?? "—"}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-8 rounded-2xl border border-blue-500/20 bg-blue-500/10 p-4">
                <p className="text-xs text-slate-200">
                  No previous session recorded yet. Your last login will appear here after you sign out.
                </p>
              </div>
            )}
          </div>

          {/* Right: Login */}
          <div className="relative rounded-3xl border border-slate-700/40 bg-slate-900/30 backdrop-blur-xl shadow-2xl p-8 lg:p-10 flex flex-col justify-center overflow-hidden">
            <div className="pointer-events-none absolute -top-24 -right-24 h-64 w-64 rounded-full bg-blue-500/10 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl" />

            <div className="absolute left-8 right-8 top-6 h-px bg-gradient-to-r from-transparent via-slate-600/50 to-transparent" />

            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-3xl sm:text-4xl font-semibold tracking-tight text-slate-50 leading-tight">Sign in</p>
                <p className="text-sm text-slate-400 mt-2">Enter your operator credentials to continue.</p>
              </div>

              <div className="h-12 w-12 rounded-2xl bg-blue-500/10 border border-blue-400/20 flex items-center justify-center">
                <User className="h-6 w-6 text-blue-300" />
              </div>
            </div>

            <div className="mt-8 space-y-3">
              {lockedReason ? (
                <div className="rounded-2xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 mt-0.5" />
                  <div className="min-w-0">
                    <p className="font-semibold">Session locked</p>
                    <p className="mt-0.5 text-amber-100/80 leading-relaxed">{lockedReason}</p>
                    <button
                      type="button"
                      onClick={clearLock}
                      className="mt-2 inline-flex items-center gap-2 rounded-xl border border-amber-500/25 bg-slate-950/25 px-3 py-2 text-[11px] text-amber-100 hover:bg-slate-950/40 transition"
                    >
                      <Lock className="h-4 w-4" /> Unlock
                    </button>
                  </div>
                </div>
              ) : null}

              <label className="text-sm font-semibold text-slate-200">Username</label>

              <div
                className={[
                  "flex items-center gap-3 rounded-2xl border bg-slate-950/40 px-4 py-4 transition",
                  "focus-within:ring-2 focus-within:ring-blue-500/25",
                  localError ? "border-rose-500/50" : "border-slate-700/60 focus-within:border-blue-500/70",
                ].join(" ")}
              >
                <User className="h-5 w-5 text-slate-400" />
                <input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onBlur={() => setTouched(true)}
                  onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                  placeholder="e.g. admin"
                  className="w-full bg-transparent outline-none text-base text-slate-100 placeholder:text-slate-500"
                  autoFocus
                />
                {usernameTrimmed ? (
                  <span className="inline-flex items-center gap-1 text-[12px] text-emerald-300">
                    <CheckCircle2 className="h-5 w-5" />
                  </span>
                ) : null}
              </div>

              <div className="flex items-center justify-between gap-3">
                <span
                  className={[
                    "inline-flex items-center rounded-full border px-2.5 py-1 text-[11px]",
                    existingUser
                      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-200"
                      : "border-slate-600/40 bg-slate-950/20 text-slate-200",
                  ].join(" ")}
                  title="Client-side user database mode"
                >
                  {existingUser ? "Existing user" : "New user"}
                </span>

                <button
                  type="button"
                  onClick={() => setShowUsers((v) => !v)}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-700/60 bg-slate-950/35 px-3 py-2 text-[11px] text-slate-200 hover:border-blue-500/40 hover:bg-slate-950/55 transition"
                  title="Browse saved users"
                >
                  <Search className="h-4 w-4 text-cyan-300" />
                  {showUsers ? "Hide users" : "Show users"}
                </button>
              </div>

              {showUsers ? (
                <div className="rounded-2xl border border-slate-700/50 bg-slate-950/25 p-3">
                  <div className="flex items-center gap-2 rounded-xl border border-slate-700/60 bg-slate-950/30 px-3 py-2">
                    <Search className="h-4 w-4 text-slate-400" />
                    <input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search users…"
                      className="w-full bg-transparent outline-none text-[12px] text-slate-100 placeholder:text-slate-500"
                    />
                  </div>

                  <div className="mt-2 max-h-40 overflow-y-auto space-y-1">
                    {matchedUsers.length ? (
                      matchedUsers.map((u) => (
                        <button
                          key={u}
                          type="button"
                          onClick={() => {
                            setUsername(u);
                            setPassword("");
                            setTouched(true);
                          }}
                          className="w-full text-left rounded-xl border border-slate-700/40 bg-slate-950/25 px-3 py-2 text-[12px] text-slate-200 hover:border-blue-500/35 hover:bg-slate-950/40 transition flex items-center justify-between gap-3"
                          title="Use this username"
                        >
                          <span className="truncate">{u}</span>
                          <span className="text-[10px] text-slate-400">saved</span>
                        </button>
                      ))
                    ) : (
                      <p className="text-[12px] text-slate-400 px-1 py-2">No users matched.</p>
                    )}
                  </div>
                </div>
              ) : null}

              <label className="text-sm font-semibold text-slate-200 mt-2 block">Password</label>

              <div
                className={[
                  "flex items-center gap-3 rounded-2xl border bg-slate-950/40 px-4 py-4 transition",
                  "focus-within:ring-2 focus-within:ring-blue-500/25",
                  localError && !passwordTrimmed
                    ? "border-rose-500/50"
                    : "border-slate-700/60 focus-within:border-blue-500/70",
                ].join(" ")}
              >
                <Lock className="h-5 w-5 text-slate-400" />
                <input
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onBlur={() => setTouched(true)}
                  onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                  placeholder="Enter password"
                  type="password"
                  className="w-full bg-transparent outline-none text-base text-slate-100 placeholder:text-slate-500"
                />
                {passwordTrimmed ? (
                  <span className="inline-flex items-center gap-1 text-[12px] text-emerald-300">
                    <CheckCircle2 className="h-5 w-5" />
                  </span>
                ) : null}
              </div>

              <p className="text-[12px] text-slate-400 leading-relaxed">{modeHelp}</p>

              {localError ? <Banner tone="danger" text={localError} /> : null}
              {error ? <Banner tone="warn" text={error} /> : null}

              <button
                onClick={handleSubmit}
                disabled={!canSubmit}
                className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 px-5 py-4 text-base font-semibold text-white shadow-lg shadow-blue-600/20 transition hover:from-blue-500 hover:to-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting || authLoading ? (
                  <>
                    Signing in
                    <Loader2 className="h-5 w-5 animate-spin" />
                  </>
                ) : (
                  <>
                    Continue
                    <ArrowRight className="h-5 w-5" />
                  </>
                )}
              </button>

              <p className="mt-4 text-[12px] text-slate-500 leading-relaxed">
                By continuing, you confirm you are authorized to access and control the target machines.
              </p>
            </div>

            <div className="mt-8 flex items-center justify-between text-[11px] text-slate-500">
              <span>Session Entry</span>
              <span>© Remote Desktop Control</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Feature({ icon, title, desc }: { icon: ReactNode; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-slate-700/40 bg-slate-950/25 p-4 hover:bg-slate-950/35 transition">
      <div className="flex items-center gap-2">
        <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-slate-900/60 border border-slate-700/40">
          {icon}
        </span>
        <p className="text-xs font-semibold text-slate-100">{title}</p>
      </div>
      <p className="mt-2 text-[11px] text-slate-400 leading-relaxed">{desc}</p>
    </div>
  );
}

function Banner({ tone, text }: { tone: "danger" | "warn"; text: string }) {
  const cls =
    tone === "danger"
      ? "border-rose-500/25 bg-rose-500/10 text-rose-200"
      : "border-amber-500/25 bg-amber-500/10 text-amber-200";
  return (
    <div className={`rounded-2xl border px-4 py-3 text-xs flex items-start gap-2 ${cls}`}>
      <AlertTriangle className="h-4 w-4 mt-0.5" />
      <span>{text}</span>
    </div>
  );
}
