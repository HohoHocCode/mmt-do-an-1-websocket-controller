import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  ShieldCheck,
  User,
  ArrowRight,
  Globe,
  Activity,
  CheckCircle2,
  AlertTriangle,
  History,
  LogIn,
  Sparkles,
  Fingerprint,
} from "lucide-react";

type Props = {
  appName: string;
  username: string;
  onUsernameChange: (v: string) => void;
  onSubmit: () => void;
  loading?: boolean;
  error?: string | null;
};

type PrevSession = {
  username: string;
  loginAt?: string | null;
  logoutAt?: string | null;
};

function formatDate(iso?: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString();
}

function calcDuration(loginAt?: string | null, logoutAt?: string | null) {
  if (!loginAt || !logoutAt) return null;
  const a = new Date(loginAt).getTime();
  const b = new Date(logoutAt).getTime();
  if (!Number.isFinite(a) || !Number.isFinite(b) || b < a) return null;
  const sec = Math.floor((b - a) / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

export default function LoginPage({
  appName,
  username,
  onUsernameChange,
  onSubmit,
  loading = false,
  error = null,
}: Props) {
  const [touched, setTouched] = useState(false);
  const [prev, setPrev] = useState<PrevSession | null>(null);

  useEffect(() => {
    const lastUsername = localStorage.getItem("rdc.lastUsername") || "";
    const lastLoginAt = localStorage.getItem("rdc.lastLoginAt");
    const lastLogoutAt = localStorage.getItem("rdc.lastLogoutAt");
    if (lastUsername) {
      setPrev({ username: lastUsername, loginAt: lastLoginAt, logoutAt: lastLogoutAt });
    }
  }, []);

  const usernameTrimmed = useMemo(() => username.trim(), [username]);

  const localError = useMemo(() => {
    if (!touched) return null;
    if (!usernameTrimmed) return "Username is required.";
    if (usernameTrimmed.length < 2) return "Username must be at least 2 characters.";
    return null;
  }, [touched, usernameTrimmed]);

  const canSubmit = !!usernameTrimmed && !loading;

  const handleSubmit = () => {
    setTouched(true);
    if (!usernameTrimmed) return;
    onSubmit();
  };

  const duration = useMemo(
    () => calcDuration(prev?.loginAt ?? null, prev?.logoutAt ?? null),
    [prev]
  );

  return (
    <div className="min-h-screen bg-[#040A18] text-slate-100 relative overflow-hidden">
      {/* Glow background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-56 -left-40 h-[680px] w-[680px] rounded-full bg-blue-600/20 blur-3xl" />
        <div className="absolute -bottom-56 -right-48 h-[720px] w-[720px] rounded-full bg-cyan-500/20 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 py-10 min-h-screen flex items-center">
        <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-8">

          {/* LEFT */}
          <div className="rounded-3xl border border-slate-700/40 bg-slate-900/30 backdrop-blur-xl p-8 lg:p-10">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-2xl bg-blue-500/15 border border-blue-400/30 flex items-center justify-center">
                <ShieldCheck className="h-6 w-6 text-blue-300" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest text-slate-400">
                  Operator Console
                </p>
                <h1 className="text-2xl sm:text-3xl font-semibold">{appName}</h1>
              </div>
            </div>

            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-slate-700/50 bg-slate-950/30 px-3 py-1.5 text-[11px]">
              <Sparkles className="h-4 w-4 text-cyan-300" />
              Session entry gateway
            </div>

            <div className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Feature icon={<Globe className="h-4 w-4 text-cyan-300" />} title="LAN-ready" />
              <Feature icon={<Activity className="h-4 w-4 text-blue-300" />} title="Visibility" />
              <Feature icon={<CheckCircle2 className="h-4 w-4 text-emerald-300" />} title="Workflow" />
              <Feature icon={<Fingerprint className="h-4 w-4 text-indigo-300" />} title="Session-first" />
            </div>

            {prev && (
              <div className="mt-8 rounded-2xl border border-slate-700/50 bg-slate-950/30 p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-xs font-semibold">Previous session</p>
                    <p className="text-[11px] text-slate-400">
                      User: <span className="text-slate-200">{prev.username}</span>
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      onUsernameChange(prev.username);
                      setTouched(true);
                    }}
                    className="inline-flex items-center gap-2 text-[11px] px-3 py-2 rounded-xl border border-slate-700/60 hover:bg-slate-800"
                  >
                    <LogIn className="h-4 w-4 text-cyan-300" />
                    Use
                  </button>
                </div>

                <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-slate-400">
                  <InfoBox label="Login" value={formatDate(prev.loginAt)} />
                  <InfoBox label="Logout" value={formatDate(prev.logoutAt)} />
                  <InfoBox label="Duration" value={duration ?? "—"} />
                </div>
              </div>
            )}
          </div>

          {/* RIGHT */}
          <div className="rounded-3xl border border-slate-700/40 bg-slate-900/40 backdrop-blur-xl p-8 lg:p-10 flex flex-col justify-center">
            <p className="text-3xl font-semibold mb-2">Sign in</p>
            <p className="text-sm text-slate-400 mb-6">
              Enter your operator username to continue.
            </p>

            <label className="text-sm font-semibold mb-2">Username</label>
            <div className={`flex items-center gap-3 rounded-2xl border px-4 py-4
              ${localError ? "border-rose-500/50" : "border-slate-700/60"}
              bg-slate-950/40 focus-within:ring-2 focus-within:ring-blue-500/25`}>
              <User className="h-5 w-5 text-slate-400" />
              <input
                value={username}
                onChange={(e) => onUsernameChange(e.target.value)}
                onBlur={() => setTouched(true)}
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                className="w-full bg-transparent outline-none"
                placeholder="e.g. admin"
              />
              {usernameTrimmed && <CheckCircle2 className="h-5 w-5 text-emerald-300" />}
            </div>

            {localError && <Banner tone="danger" text={localError} />}
            {error && <Banner tone="warn" text={error} />}

            <button
              onClick={handleSubmit}
              disabled={!canSubmit}
              className="mt-5 inline-flex items-center justify-center gap-2 rounded-2xl
                         bg-gradient-to-r from-blue-600 to-cyan-500
                         px-5 py-4 text-base font-semibold text-white
                         hover:from-blue-500 hover:to-cyan-400 transition
                         disabled:opacity-50">
              Continue <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* Helpers */

function Feature({ icon, title }: { icon: ReactNode; title: string }) {
  return (
    <div className="rounded-2xl border border-slate-700/40 bg-slate-950/25 p-4">
      <div className="flex items-center gap-2">
        <span className="h-8 w-8 flex items-center justify-center rounded-xl bg-slate-900/60 border border-slate-700/40">
          {icon}
        </span>
        <p className="text-xs font-semibold">{title}</p>
      </div>
    </div>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-700/40 bg-slate-950/25 px-3 py-2">
      <p className="text-slate-500">{label}</p>
      <p className="text-slate-200">{value}</p>
    </div>
  );
}

function Banner({ tone, text }: { tone: "danger" | "warn"; text: string }) {
  const cls =
    tone === "danger"
      ? "border-rose-500/30 bg-rose-500/10 text-rose-300"
      : "border-amber-500/30 bg-amber-500/10 text-amber-300";
  return (
    <div className={`mt-3 rounded-2xl border px-4 py-3 text-xs flex gap-2 ${cls}`}>
      <AlertTriangle className="h-4 w-4" />
      <span>{text}</span>
    </div>
  );
}
